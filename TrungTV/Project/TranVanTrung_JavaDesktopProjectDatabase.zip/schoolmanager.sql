-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2019 at 09:43 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schoolmanager`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `Class_ID` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Name_of_class` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Teacher_ID` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `School_year` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`Class_ID`, `Name_of_class`, `Teacher_ID`, `School_year`) VALUES
('CLC1', 'FFSE1803', 'JV01', 2018),
('CLC2', 'FFSE1901', 'JV04', 2019);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Username` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Password` char(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Username`, `Password`) VALUES
('admin', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `mark`
--

CREATE TABLE `mark` (
  `Subject_ID` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ID` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Mid_test` double(3,2) DEFAULT NULL,
  `Final_test` double(3,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mark`
--

INSERT INTO `mark` (`Subject_ID`, `ID`, `Mid_test`, `Final_test`) VALUES
('SD01', 'ST01', 10.00, 8.00),
('SD02', 'ST01', 10.00, 10.00),
('SD01', 'ST02', 4.50, 6.70),
('SD02', 'ST02', 6.70, 5.30);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Last_name` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `First_name` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Birthday` date NOT NULL,
  `Sex` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Country` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Class_ID` char(5) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `Last_name`, `First_name`, `Birthday`, `Sex`, `Country`, `Class_ID`) VALUES
('ST01', 'Potter', 'Harry', '2000-06-12', 'Nữ', 'Vietnamese', 'CLC1'),
('ST02', 'Trần Văn', 'Hoàng Hải', '2000-06-01', 'Nam', 'China', 'CLC2'),
('ST04', 'Hà Phước', 'Yên', '2000-10-10', 'Nam', 'Indonexia', 'CLC2');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `Subject_ID` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Subject` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Credits` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`Subject_ID`, `Subject`, `Credits`) VALUES
('SD01', 'JavaCore', 3),
('SD02', 'HTML & CSS', 5),
('SD03', 'English', 4),
('SD04', 'JavaDesktop', 7),
('SD05', 'JavaWeb', 5);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `Teacher_ID` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Name` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Subject_ID` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Level` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Phone_No` char(12) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`Teacher_ID`, `Name`, `Subject_ID`, `Level`, `Phone_No`) VALUES
('JV01', 'Mr.Thang', 'SD01', 'Doctor', '0356647463'),
('JV02', 'Mrs.Quyen', 'SD02', 'Manter', '0362750459'),
('JV03', 'Mr.Trung', 'SD03', 'Professor', '01642750459'),
('JV04', 'Mr.Huong', 'SD04', 'Manter', '0123456789');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`Class_ID`),
  ADD KEY `Teacher_ID` (`Teacher_ID`) USING BTREE;

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `mark`
--
ALTER TABLE `mark`
  ADD KEY `ID` (`ID`),
  ADD KEY `Subject_ID` (`Subject_ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Class_ID` (`Class_ID`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`Subject_ID`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`Teacher_ID`),
  ADD KEY `Subject's_ID` (`Subject_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `class`
--
ALTER TABLE `class`
  ADD CONSTRAINT `class_ibfk_1` FOREIGN KEY (`Teacher_ID`) REFERENCES `teacher` (`Teacher_ID`);

--
-- Constraints for table `mark`
--
ALTER TABLE `mark`
  ADD CONSTRAINT `mark_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `student` (`ID`),
  ADD CONSTRAINT `mark_ibfk_2` FOREIGN KEY (`Subject_ID`) REFERENCES `subjects` (`Subject_ID`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`Class_ID`) REFERENCES `class` (`Class_ID`);

--
-- Constraints for table `teacher`
--
ALTER TABLE `teacher`
  ADD CONSTRAINT `teacher_ibfk_1` FOREIGN KEY (`Subject_ID`) REFERENCES `subjects` (`Subject_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
