
-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `monhoc`
--

CREATE TABLE `monhoc` (
  `id` int(11) NOT NULL,
  `maMonHoc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tenMonHoc` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maNhanVien` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `soTiet` int(11) DEFAULT NULL,
  `ghiChu` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `monhoc`
--

INSERT INTO `monhoc` (`id`, `maMonHoc`, `tenMonHoc`, `maNhanVien`, `soTiet`, `ghiChu`) VALUES
(1, 'MT', 'Môn Toán', 'GV1001', 19, ''),
(10, 'ML', 'Môn Lý', 'GV1002', 19, ''),
(11, 'MD', 'Môn Địa', 'GV1103', 19, ''),
(12, 'ML', 'Môn Lý', 'GV1002', 19, ''),
(14, 'MV', 'Môn Văn', 'GV1101', 19, '');
