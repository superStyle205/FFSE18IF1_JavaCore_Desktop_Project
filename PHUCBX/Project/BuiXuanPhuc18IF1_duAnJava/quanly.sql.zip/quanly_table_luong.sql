
-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `luong`
--

CREATE TABLE `luong` (
  `id` int(11) NOT NULL,
  `maGiaoVien` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tenGiaoVien` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thang` int(11) DEFAULT NULL,
  `heSoLuong` int(50) DEFAULT NULL,
  `phuCap` int(50) DEFAULT NULL,
  `soNgayLamViec` int(11) DEFAULT NULL,
  `luongTamUng` int(50) DEFAULT NULL,
  `tienLuong` int(50) DEFAULT NULL,
  `tienThuong` int(50) DEFAULT NULL,
  `tongLuong` int(50) DEFAULT NULL,
  `ghiChu` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `luong`
--

INSERT INTO `luong` (`id`, `maGiaoVien`, `tenGiaoVien`, `thang`, `heSoLuong`, `phuCap`, `soNgayLamViec`, `luongTamUng`, `tienLuong`, `tienThuong`, `tongLuong`, `ghiChu`) VALUES
(7, 'GV1001', 'Phạm Mạnh Hùng', 4, 3, 3000, 19, 123012, 3420000, 30000, 10169988, ''),
(8, 'GV1101', 'Nguyễn Chí Thanh', 4, 2, 40000, 13, 123012, 2340000, 30000, 4626988, ''),
(9, 'GV1201', 'Trần Đình Kiên', 4, 5, 90000, 17, 0, 3060000, 30000, 15420000, '');
