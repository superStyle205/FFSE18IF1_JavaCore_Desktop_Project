
-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hosohocsinh`
--

CREATE TABLE `hosohocsinh` (
  `id` int(20) NOT NULL,
  `maLop` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maHocSinh` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tenHocSinh` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gioiTinh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngaySinh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noiSinh` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `diaChi` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hoTenBo` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hoTenMe` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `soDienThoai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghiChu` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `hosohocsinh`
--

INSERT INTO `hosohocsinh` (`id`, `maLop`, `maHocSinh`, `tenHocSinh`, `gioiTinh`, `ngaySinh`, `noiSinh`, `diaChi`, `Email`, `hoTenBo`, `hoTenMe`, `soDienThoai`, `ghiChu`) VALUES
(1, 'L10A1', 'HS1001', 'Xuân Thanh', 'Nữ', '2000-07-19', 'Gia Lai', 'Huyện Chư Sê, Tỉnh Gia Lai', 'mewmew@gmail.com', 'Bùi Xuân Hòa', 'Phan Thị Then', '0154142543', ''),
(2, 'L10A2', 'HS1002', 'Xuân Tài', 'Nam', '2000-02-12', 'Gia Lai', 'Huyện Chư Sê, Tỉnh Gia Lai', 'mewmew@gmail.com', 'Xuân ', 'Hậ', '0154142543', ''),
(3, 'L11A3', 'HS1103', 'Chí Tài', 'Nam', '2000-02-12', 'Gia Lai', 'Huyện Chư Sê, Tỉnh Gia Lai', 'mewmew@gmail.com', 'Xuân ', 'Bao', '0154142543', ''),
(4, 'L11A1', 'HS1102', 'Chí ', 'Nam', '2000-02-12', 'Gia Lai', 'Huyện Chư Sê, Tỉnh Gia Lai', 'mewmew@gmail.com', 'Xuân ', 'Bao', '0154142543', '');
