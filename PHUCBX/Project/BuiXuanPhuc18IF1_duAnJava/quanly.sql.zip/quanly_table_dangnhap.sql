
-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dangnhap`
--

CREATE TABLE `dangnhap` (
  `id` int(11) DEFAULT NULL,
  `tenTaiKhoan` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `matKhau` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `dangnhap`
--

INSERT INTO `dangnhap` (`id`, `tenTaiKhoan`, `matKhau`) VALUES
(1, 'giaovien', '123456'),
(2, 'hocsinh', '123456');
