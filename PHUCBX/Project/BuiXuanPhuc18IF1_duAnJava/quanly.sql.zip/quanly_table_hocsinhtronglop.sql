
-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hocsinhtronglop`
--

CREATE TABLE `hocsinhtronglop` (
  `id` int(11) NOT NULL,
  `maLop` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maHocSinh` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tenHocSinh` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gioiTinh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngaySinh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hanhKiem` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghiChu` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `hocsinhtronglop`
--

INSERT INTO `hocsinhtronglop` (`id`, `maLop`, `maHocSinh`, `tenHocSinh`, `gioiTinh`, `ngaySinh`, `hanhKiem`, `ghiChu`) VALUES
(1, 'L10A1', 'HS1001', 'Bùi Xuân Phúc', 'Nam', '2000-07-19', 'Tốt', ''),
(2, 'L10A2', 'HS1002', 'Nguyễn Tuấn Triều', 'Nam', '2000-05-12', 'Tốt', ''),
(3, 'L11A1', 'HS1102', 'Nguyễn Chí Thanh', 'Nam', '1999-12-03', 'Tốt', ''),
(4, 'L11A2', 'HS1101', 'Lê Thanh Tài', 'Nam', '1999-02-12', 'Tốt', ''),
(5, 'L11A3', 'HS1103', 'Lê Thanh Nghị', 'Nam', '1999-02-12', 'Tốt', ''),
(9, 'L12A1', 'HS1201', 'Lê Thanh ', 'Nam', '1999-02-12', 'Tốt', ''),
(10, 'L12A2', 'HS1203', 'Lê Thanh Nam', 'Nam', '1999-02-12', 'Tốt', '');
