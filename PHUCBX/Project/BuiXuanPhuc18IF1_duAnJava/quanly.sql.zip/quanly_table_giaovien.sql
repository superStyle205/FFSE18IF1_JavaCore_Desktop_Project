
-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `giaovien`
--

CREATE TABLE `giaovien` (
  `id` int(11) NOT NULL,
  `maPhongBan` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maNhanVien` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tenNhanVien` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chucVu` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngaySinh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `diaChi` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `danToc` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tonGiao` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngayVaoLamViec` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `queQuan` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nguyenQuan` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SoDienThoai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghiChu` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `giaovien`
--

INSERT INTO `giaovien` (`id`, `maPhongBan`, `maNhanVien`, `tenNhanVien`, `chucVu`, `ngaySinh`, `diaChi`, `danToc`, `tonGiao`, `ngayVaoLamViec`, `queQuan`, `nguyenQuan`, `SoDienThoai`, `Email`, `ghiChu`) VALUES
(108, 'PGV', 'GV1001', 'Phạm Mạnh Hùng', 'Giáo Viên', '1987-10-09', 'GIa Lai', 'Kinh', 'không', '1999-10-09', 'Gia Lai', 'Thừa Thiên Huế', '0129231234', 'mewmew@gmail.com', ''),
(109, 'PGV', 'GV1002', 'Nguyễn Thanh Thiên', 'Giáo Viên', '1987-10-09', 'GIa Lai', 'Kinh', 'không', '1999-10-09', 'Gia Lai', 'Thừa Thiên Huế', '0129231234', 'mewmew@gmail.com', ''),
(110, 'PGV', 'GV1101', 'Trần Đình Kiên', 'Giáo Viên', '1987-10-09', 'GIa Lai', 'Kinh', 'không', '1999-10-09', 'Gia Lai', 'Thừa Thiên Huế', '0129231234', 'mewmew@gmail.com', ''),
(111, 'PGV', 'GV1201', 'Nguyễn Thành Công', 'Giáo Viên', '1987-10-09', 'GIa Lai', 'Kinh', 'không', '1999-10-09', 'Gia Lai', 'Thừa Thiên Huế', '0129231234', 'mewmew@gmail.com', '');
