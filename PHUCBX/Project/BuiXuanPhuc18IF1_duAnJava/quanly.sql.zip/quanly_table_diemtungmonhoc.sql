
-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `diemtungmonhoc`
--

CREATE TABLE `diemtungmonhoc` (
  `id` int(11) NOT NULL,
  `maLop` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maMonHoc` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maHocKi` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maHocSinh` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tenHocSinh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Mieng` double DEFAULT NULL,
  `diem15pLan1` double DEFAULT NULL,
  `diem15pLan2` double DEFAULT NULL,
  `diem1Tiet` double DEFAULT NULL,
  `diemHocKi` double DEFAULT NULL,
  `ghiChu` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `diemtungmonhoc`
--

INSERT INTO `diemtungmonhoc` (`id`, `maLop`, `maMonHoc`, `maHocKi`, `maHocSinh`, `tenHocSinh`, `Mieng`, `diem15pLan1`, `diem15pLan2`, `diem1Tiet`, `diemHocKi`, `ghiChu`) VALUES
(1, 'L10A1', 'MT', 'Hk1', 'HS1002', 'Xuân Phúc', 8, 6, 8, 8, 7, ''),
(2, 'L10A2', 'ML', 'Hk1', 'HS1002', 'Chí Tài', 8.5, 6, 8, 8, 7, '');
