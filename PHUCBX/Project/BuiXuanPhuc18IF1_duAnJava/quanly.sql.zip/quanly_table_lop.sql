
-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lop`
--

CREATE TABLE `lop` (
  `id` int(11) NOT NULL,
  `maKhoi` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maLop` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `tenLop` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maNhanVien` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tenNhanVien` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `nienKhoa` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghiChu` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `lop`
--

INSERT INTO `lop` (`id`, `maKhoi`, `maLop`, `tenLop`, `maNhanVien`, `tenNhanVien`, `nienKhoa`, `ghiChu`) VALUES
(1, 'K10', 'L10A1', '10A1', 'GV1001', 'Phạm Mạnh Hùng', '2016-2019', ''),
(2, 'K10', 'L10A2', '10A2', 'GV1002', 'Nguyễn Thành Danh', '2016-2019', ''),
(4, 'K11', 'L11A1', '11A1', 'GV1101', 'Lê Xuân Nguyên', '2015-2018', ''),
(5, 'K11', 'L11A2', '11A2', 'GV1102', 'Bùi Đình Tiến', '2015-2018', 'Lớp Nâng Cao'),
(7, 'K12', 'L12A1', '12A1', 'GV1201', 'IronMan', '2016-2019', 'Lớp Nâng Cao');
