-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 20, 2019 lúc 11:20 AM
-- Phiên bản máy phục vụ: 10.1.37-MariaDB
-- Phiên bản PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `project`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `diem`
--

CREATE TABLE `diem` (
  `idlop` varchar(45) NOT NULL,
  `mon` varchar(45) DEFAULT NULL,
  `idmon` varchar(45) NOT NULL,
  `idhs` varchar(45) NOT NULL,
  `diem15` decimal(3,1) DEFAULT NULL,
  `diem45` decimal(3,1) DEFAULT NULL,
  `diemthi` decimal(3,1) DEFAULT NULL,
  `tongket` decimal(3,1) DEFAULT NULL,
  `ketqua` varchar(45) DEFAULT NULL,
  `idgv` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `diem`
--

INSERT INTO `diem` (`idlop`, `mon`, `idmon`, `idhs`, `diem15`, `diem45`, `diemthi`, `tongket`, `ketqua`, `idgv`) VALUES
('LOP122', 'Văn', 'Van', 'HS007', '4.0', '3.0', '4.0', '3.8', 'Không đạt', 'GV002'),
('LOP122', 'Văn', 'Van', 'HS008', '7.0', '7.0', '7.0', '7.0', 'Đạt', 'GV002'),
('LOP122', 'Văn', 'Van', 'HS001', '10.0', '10.0', '10.0', '10.0', 'Đạt', 'GV002'),
('LOP122', 'Văn', 'Van', 'HS006', '10.0', '10.0', '10.0', '10.0', 'Đạt', 'GV002'),
('LOP122', 'Văn', 'Van', 'HS010', '10.0', '5.0', '10.0', '8.8', 'Đạt', 'GV002');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `giaovien`
--

CREATE TABLE `giaovien` (
  `idgv` varchar(45) NOT NULL,
  `hoten` varchar(45) DEFAULT NULL,
  `idmon` varchar(45) DEFAULT NULL,
  `idlop` varchar(45) DEFAULT NULL,
  `ngaysinh` date DEFAULT NULL,
  `gioitinh` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `sdt` varchar(45) DEFAULT NULL,
  `pass` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `giaovien`
--

INSERT INTO `giaovien` (`idgv`, `hoten`, `idmon`, `idlop`, `ngaysinh`, `gioitinh`, `email`, `sdt`, `pass`) VALUES
('GV001', 'Đạt G', 'Anh', 'LOP10A1', '1990-04-16', 'Nam', 'datg12345@gmail.com', '0905569438', 'g'),
('GV002', 'Chi Pu', 'Van', 'LOP122', '1990-10-25', 'Nữ', 'chipu123@gmail.com', '0905569438', 'a'),
('GV003', 'Masew', 'LS', 'LOP111', '1901-05-31', 'Nam', 'masew12345@gmail.com', '0905123456', 'hahaha'),
('GV004', 'Chi Pu Cu', 'Hoa', 'LOP122', '1990-06-01', 'Nữ', 'chipucu123@gmail.com', '0905569438', 'huhu'),
('GV005', 'Link Ka', 'Toan', 'LOP10A1', '1997-06-07', 'Nữ', 'linkka12345@gmail.com', '0905569438', '123');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lop`
--

CREATE TABLE `lop` (
  `idlop` varchar(45) NOT NULL,
  `lop` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `lop`
--

INSERT INTO `lop` (`idlop`, `lop`) VALUES
('LOP10A1', '10/1'),
('LOP10A2', '10/2'),
('LOP111', '11/1'),
('LOP112', '11/2'),
('LOP121', '12/1'),
('LOP122', '12/2');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `mon`
--

CREATE TABLE `mon` (
  `idmon` varchar(45) NOT NULL,
  `mon` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `mon`
--

INSERT INTO `mon` (`idmon`, `mon`) VALUES
('Anh', 'Anh'),
('CNTT', 'Công Nghệ Thông Tin'),
('Dia', 'Địa'),
('GDCD', 'Giáo Dục Công Dân'),
('GDQP', 'Giáo Dục Quốc Phòng'),
('Hoa', 'Hóa'),
('LS', 'Lịch Sử'),
('Sinh', 'Sinh'),
('Tin', 'TIn'),
('Toan', 'Toán'),
('Van', 'Văn'),
('VL', 'Vật Lí');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sinhvien`
--

CREATE TABLE `sinhvien` (
  `idhs` varchar(45) NOT NULL,
  `hoten` varchar(45) DEFAULT NULL,
  `idlop` varchar(45) DEFAULT NULL,
  `ngaysinh` date DEFAULT NULL,
  `diachi` varchar(45) DEFAULT NULL,
  `gioitinh` varchar(45) DEFAULT NULL,
  `sdt` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `sinhvien`
--

INSERT INTO `sinhvien` (`idhs`, `hoten`, `idlop`, `ngaysinh`, `diachi`, `gioitinh`, `sdt`) VALUES
('HS001', 'Nguyễn Viết Quang Huy', 'LOP122', '2000-07-07', 'Đà Nẵng', 'Nam', '0769753362'),
('HS002', 'Thị Nở', 'LOP10A2', '2000-06-01', 'Đà Nẵng', 'Nữ', '0905716529'),
('HS003', 'Trần Văn Hoàng Hải', 'LOP10A1', '2000-10-25', 'Đà Nẵng', 'Nam', '0905569438'),
('HS004', 'Nguyên Oanh', 'LOP10A2', '2000-06-14', 'Điện Dương', 'Nữ', '0905569438'),
('HS005', 'Thị Nở', 'LOP10A2', '2000-06-12', 'Đà Nẵng', 'Nam', '0905716529'),
('HS006', 'Chí Phèo', 'LOP122', '2000-06-01', 'Đà Nẵng', 'Nữ', '0905716529'),
('HS007', 'Nguyễn Viết Quang Huy', 'LOP122', '2000-06-03', 'Đà Nẵng', 'Nam', '0769753362'),
('HS008', 'Nguyễn Viết Quang Huy', 'LOP122', '2000-06-07', 'Đà Nẵng', 'Nữ', '0123456789'),
('HS009', 'Nguyễn Viết Quang Huy', 'LOP122', '2001-07-06', 'Đà Nẵng', 'Nữ', '0123456789'),
('HS010', 'Nguyễn Viết Quang Huy', 'LOP122', '2000-07-07', 'Đà Nẵng', 'Nam', '0769753362');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `ID` int(10) NOT NULL,
  `username` char(15) NOT NULL,
  `pass` char(15) NOT NULL,
  `role` int(2) NOT NULL,
  `FullName` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`ID`, `username`, `pass`, `role`, `FullName`) VALUES
(1, 'admin', 'admin', 1, 'Trần Văn Hoàng Hải'),
(2, 'gv', 'giaovu', 2, 'Hoàng Hải'),
(3, 'gv1', 'gv1', 2, 'Quang Huy');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `diem`
--
ALTER TABLE `diem`
  ADD KEY `FK_Mon_idx` (`idmon`),
  ADD KEY `FK_SV_idx` (`idhs`),
  ADD KEY `idlop` (`idlop`),
  ADD KEY `idgv` (`idgv`);

--
-- Chỉ mục cho bảng `giaovien`
--
ALTER TABLE `giaovien`
  ADD PRIMARY KEY (`idgv`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `FK_IDmon_idx` (`idmon`),
  ADD KEY `idlop` (`idlop`);

--
-- Chỉ mục cho bảng `lop`
--
ALTER TABLE `lop`
  ADD PRIMARY KEY (`idlop`);

--
-- Chỉ mục cho bảng `mon`
--
ALTER TABLE `mon`
  ADD PRIMARY KEY (`idmon`);

--
-- Chỉ mục cho bảng `sinhvien`
--
ALTER TABLE `sinhvien`
  ADD PRIMARY KEY (`idhs`),
  ADD KEY `FK_Lop_idx` (`idlop`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `username_2` (`username`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `diem`
--
ALTER TABLE `diem`
  ADD CONSTRAINT `FK_Mon` FOREIGN KEY (`idmon`) REFERENCES `mon` (`idmon`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_SV` FOREIGN KEY (`idhs`) REFERENCES `sinhvien` (`idhs`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `diem_ibfk_1` FOREIGN KEY (`idlop`) REFERENCES `lop` (`idlop`),
  ADD CONSTRAINT `diem_ibfk_2` FOREIGN KEY (`idgv`) REFERENCES `giaovien` (`idgv`);

--
-- Các ràng buộc cho bảng `giaovien`
--
ALTER TABLE `giaovien`
  ADD CONSTRAINT `FK_IDmon` FOREIGN KEY (`idmon`) REFERENCES `mon` (`idmon`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `giaovien_ibfk_1` FOREIGN KEY (`idlop`) REFERENCES `lop` (`idlop`);

--
-- Các ràng buộc cho bảng `sinhvien`
--
ALTER TABLE `sinhvien`
  ADD CONSTRAINT `FK_Lop` FOREIGN KEY (`idlop`) REFERENCES `lop` (`idlop`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
