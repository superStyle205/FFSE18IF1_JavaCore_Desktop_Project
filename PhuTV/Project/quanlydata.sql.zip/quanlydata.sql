-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 20, 2019 lúc 11:15 AM
-- Phiên bản máy phục vụ: 10.1.37-MariaDB
-- Phiên bản PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `quanlydata`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bangdiem`
--

CREATE TABLE `bangdiem` (
  `STT` int(10) NOT NULL,
  `MaHocSinh` int(10) DEFAULT NULL,
  `MaMonHoc` int(10) DEFAULT NULL,
  `DiemDauNam` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DiemGiuaKy` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DiemCuoiKy` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DiemTongKet` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `bangdiem`
--

INSERT INTO `bangdiem` (`STT`, `MaHocSinh`, `MaMonHoc`, `DiemDauNam`, `DiemGiuaKy`, `DiemCuoiKy`, `DiemTongKet`) VALUES
(1, 1803001, 32323, '7.8', '8.0', '8.5', '8.5'),
(2, 1803001, 32323, '7.8', '8.0', '10', '8.5'),
(3, 1803047, 32325, '7.8', '7', '8.5', '8.0'),
(4, 1803063, 32327, '6', '7', '8', '7');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dangnhap`
--

CREATE TABLE `dangnhap` (
  `TaiKhoan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MatKhau` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `dangnhap`
--

INSERT INTO `dangnhap` (`TaiKhoan`, `MatKhau`) VALUES
('admin', '123456');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `giaovien`
--

CREATE TABLE `giaovien` (
  `MaGiaoVien` int(10) NOT NULL,
  `HoTenGiaoVien` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ChucVu` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GioiTinh` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DiaChi` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SoDienThoai` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `giaovien`
--

INSERT INTO `giaovien` (`MaGiaoVien`, `HoTenGiaoVien`, `ChucVu`, `GioiTinh`, `DiaChi`, `SoDienThoai`) VALUES
(6565, 'Trần Cao Vân', 'Hiệu Trưởng', 'Nam', 'Đà Nẵng', '0925983284'),
(6566, 'Phan Kim Liên', 'Giáo Viên Bộ Môn', 'Nu', 'Hà Nội', '0866635237'),
(6567, 'Châu Khải Phong', 'Phó Hiệu Trưởng', 'Nam', 'Thái Bình', '0938284823'),
(6568, 'Mỹ Tâm', 'Giáo Viên Bộ Môn', 'Nu', 'Đà Nẵng', '0827736212');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hocsinh`
--

CREATE TABLE `hocsinh` (
  `MaHocSinh` int(10) NOT NULL,
  `MaLop` int(10) DEFAULT NULL,
  `HoTen` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NgaySinh` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GioiTinh` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NoiSinh` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DanToc` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TonGiao` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NienKhoa` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SdtPhuHuynh` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `hocsinh`
--

INSERT INTO `hocsinh` (`MaHocSinh`, `MaLop`, `HoTen`, `NgaySinh`, `GioiTinh`, `NoiSinh`, `DanToc`, `TonGiao`, `NienKhoa`, `SdtPhuHuynh`) VALUES
(1803001, 1, 'Phú Trần', '26/06/2000', 'Nu', 'Hà Nội', 'Kinh', 'Không', '2019', 847732722),
(1803027, 1, 'Phạm Trọng Anh', '26/06/2000', 'Nam', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803031, 1, 'Đặng Tuấn Anh', '08/12/2008', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 1283973283),
(1803032, 1, 'Hoàng Đức Anh', '26/06/2000', 'Nam', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803033, 1, 'Phạm Thị Hiền Anh', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803034, 1, 'Phạm Thị Hiền Anh', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803035, 1, 'Phạm Thị Hiền Anh', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803037, 1, 'Phạm Thị Hiền Anh', '19/06/2000', 'Nam', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803038, 1, 'Phạm Tuấn Nam', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803039, 1, 'Phạm Thị Hiền Anh', '19/06/2000', 'Nam', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803040, 1, 'Lê Khánh Vy', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803041, 1, '	Trịnh Thiên Trường', '19/06/2000', 'Nam', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803042, 1, '	Đặng Thành Trung', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803043, 1, 'Đặng Huyền Thi', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803044, 1, 'Vũ Phương Thảo', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803045, 1, 'Nguyễn Đăng Quang', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803046, 1, 'Hoàng Gia Trọng Phúc', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803047, 1, 'Cao Nguyễn Bảo Phúc', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803048, 1, 'Nguyễn Hoàng Bảo Nhi', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803049, 1, 'Phạm Nhiên Khánh Nhi', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803050, 1, 'Phạm Minh Nhật', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803051, 1, 'Nguyễn Thị Minh Ngọc', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803052, 1, 'Nguyễn Trung Nghĩa', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803053, 1, 'Phạm Trần Hoàng Minh', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803054, 1, 'Lã Hiền Minh', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803055, 1, 'Lê Minh Long', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803056, 1, 'Trần Tuấn Đạt', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803057, 1, 'Vũ Bá Đại', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803058, 1, 'Đỗ Thùy Dương', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803059, 1, '	Ng. Hoàng Tiến  Dũng', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803060, 1, '	Lê Minh Châu', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803061, 1, 'Tô Thành Bách', '19/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803062, 1, 'Hoàng Đức Anh', '26/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722),
(1803063, 1, 'Hoàng Đức Anh', '26/06/2000', 'Nu', 'Đà Nẵng', 'Kinh', 'Không', '2019', 847732722);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lop`
--

CREATE TABLE `lop` (
  `MaLop` int(10) NOT NULL,
  `MaGiaoVien` int(10) DEFAULT NULL,
  `TenLop` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TenLopTruong` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `lop`
--

INSERT INTO `lop` (`MaLop`, `MaGiaoVien`, `TenLop`, `TenLopTruong`) VALUES
(1, 6565, 'Lớp 2A', 'Sơn Tùng'),
(3, 6565, 'Lớp 3A', 'Phú Trần'),
(4, 6565, 'Lớp 4A', 'Phú Trần'),
(6, 6565, 'Lớp 5A', 'Trần Cung '),
(8, 6565, 'Lớp 6A', 'Phạm Thu Hiền'),
(9, 6565, 'Lớp 7A', 'Hoàng An Đông'),
(10, 6565, 'Lớp 8A', 'Trần Cung '),
(11, 6565, 'Lớp 9A', 'Phi Vũ'),
(12, 6565, 'Lớp 10A', 'Vũ Trung'),
(13, 6565, 'Lớp 12A', 'Nguyễn Hùng Anh'),
(14, 6565, 'Lớp 12A', 'Nam Blu'),
(15, 6565, 'Lớp 13A', 'Trần Kim Anh');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `monhoc`
--

CREATE TABLE `monhoc` (
  `MaMonHoc` int(10) NOT NULL,
  `TenMonHoc` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `monhoc`
--

INSERT INTO `monhoc` (`MaMonHoc`, `TenMonHoc`) VALUES
(32323, 'Toán Học'),
(32324, 'Ngữ Văn'),
(32325, 'Hóa Học'),
(32326, 'Địa Lý'),
(32327, 'Khoa Học'),
(32328, 'Tiếng Anh'),
(32329, 'Tiếng Hàn'),
(32330, 'Tiếng Việt');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `bangdiem`
--
ALTER TABLE `bangdiem`
  ADD PRIMARY KEY (`STT`),
  ADD KEY `MaMonHoc` (`MaMonHoc`),
  ADD KEY `MaHocSinh` (`MaHocSinh`);

--
-- Chỉ mục cho bảng `giaovien`
--
ALTER TABLE `giaovien`
  ADD PRIMARY KEY (`MaGiaoVien`);

--
-- Chỉ mục cho bảng `hocsinh`
--
ALTER TABLE `hocsinh`
  ADD PRIMARY KEY (`MaHocSinh`),
  ADD KEY `MaLop` (`MaLop`);

--
-- Chỉ mục cho bảng `lop`
--
ALTER TABLE `lop`
  ADD PRIMARY KEY (`MaLop`),
  ADD KEY `MaGiaoVien` (`MaGiaoVien`);

--
-- Chỉ mục cho bảng `monhoc`
--
ALTER TABLE `monhoc`
  ADD PRIMARY KEY (`MaMonHoc`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `bangdiem`
--
ALTER TABLE `bangdiem`
  MODIFY `STT` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `giaovien`
--
ALTER TABLE `giaovien`
  MODIFY `MaGiaoVien` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6569;

--
-- AUTO_INCREMENT cho bảng `hocsinh`
--
ALTER TABLE `hocsinh`
  MODIFY `MaHocSinh` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1803064;

--
-- AUTO_INCREMENT cho bảng `lop`
--
ALTER TABLE `lop`
  MODIFY `MaLop` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `monhoc`
--
ALTER TABLE `monhoc`
  MODIFY `MaMonHoc` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32331;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `bangdiem`
--
ALTER TABLE `bangdiem`
  ADD CONSTRAINT `bangdiem_ibfk_1` FOREIGN KEY (`MaMonHoc`) REFERENCES `monhoc` (`MaMonHoc`),
  ADD CONSTRAINT `bangdiem_ibfk_2` FOREIGN KEY (`MaHocSinh`) REFERENCES `hocsinh` (`MaHocSinh`);

--
-- Các ràng buộc cho bảng `hocsinh`
--
ALTER TABLE `hocsinh`
  ADD CONSTRAINT `hocsinh_ibfk_1` FOREIGN KEY (`MaLop`) REFERENCES `lop` (`MaLop`);

--
-- Các ràng buộc cho bảng `lop`
--
ALTER TABLE `lop`
  ADD CONSTRAINT `lop_ibfk_1` FOREIGN KEY (`MaGiaoVien`) REFERENCES `giaovien` (`MaGiaoVien`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
