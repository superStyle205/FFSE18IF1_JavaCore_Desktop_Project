-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2019 at 10:22 AM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schoolmanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `bangdiem`
--

CREATE TABLE `bangdiem` (
  `maHocSinh` int(5) NOT NULL,
  `maMonHoc` char(5) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `diem15P1` float NOT NULL,
  `diem15P2` float NOT NULL,
  `diem1T` float NOT NULL,
  `diemCuoiKy1` float NOT NULL,
  `diemCuoiKy2` float NOT NULL,
  `tongDiem` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `bangdiem`
--

INSERT INTO `bangdiem` (`maHocSinh`, `maMonHoc`, `diem15P1`, `diem15P2`, `diem1T`, `diemCuoiKy1`, `diemCuoiKy2`, `tongDiem`) VALUES
(1, 'van', 5, 5, 5, 5, 5, 5),
(3, 'van', 9, 9, 9, 9, 9, 9),
(2, 'toan', 9, 9, 9, 9, 9, 9),
(4, 'toan', 3, 3, 3, 3, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `giaovien`
--

CREATE TABLE `giaovien` (
  `maGiaoVien` int(5) NOT NULL,
  `tenGiaoVien` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ngaySinhGV` char(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `gioiTinhGV` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `queQuanGV` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `SDTGV` char(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `trinhDo` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` char(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ghiChuGV` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `giaovien`
--

INSERT INTO `giaovien` (`maGiaoVien`, `tenGiaoVien`, `ngaySinhGV`, `gioiTinhGV`, `queQuanGV`, `SDTGV`, `trinhDo`, `email`, `ghiChuGV`) VALUES
(1, 'Đoàn Thị Hương', '30/03/1990', 'Nữ', 'Bình Dương - Thăng Bình - Quảng Nam', '0905591616', 'Cao Học', 'huongthi@gmail.com', ''),
(2, 'Trần Văn Khanh', '12/05/1995', 'Nam', 'Bình Dương - Thăng Bình - Quảng Nam', '0384616614', 'Đại Học', 'khanhvan@gmail.com', ''),
(3, 'Phan Văn Tùng', '18/10/1992', 'Nam', 'Bình Dương - Thăng Bình - Quảng Nam', '0905266448', 'Đại Học', 'tungvan@gmail.com', ''),
(4, 'Đào Thị Thu', '06/24/1987', 'Nữ', 'Bình Dương - Thăng Bình - Quảng Nam', '0352919683', 'Cao Học', 'manhduy@gmail.com', ''),
(5, 'Cao Thái Phiên', '16/09/1992', 'Nam', 'Bình Dương - Thăng Bình - Quảng Nam', '0905615163', 'Đại Học', 'phienthai@gmail.com', ''),
(6, 'ngô thị bắp', '06/05/1966', 'Nữ', 'quảng nam', '06442452476', 'đại học', 'bapthi@gmail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `hocsinh`
--

CREATE TABLE `hocsinh` (
  `maHocSinh` int(5) NOT NULL,
  `tenHocSinh` varchar(20) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `ngaySinhHS` char(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `gioiTinhHS` char(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `queQuanHS` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `SDTHocSinh` char(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `maLop` char(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `hoTenCha` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hoTenMe` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `SDTPhuHuynh` char(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `diaChiLienHe` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ghiChuHS` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `hocsinh`
--

INSERT INTO `hocsinh` (`maHocSinh`, `tenHocSinh`, `ngaySinhHS`, `gioiTinhHS`, `queQuanHS`, `SDTHocSinh`, `maLop`, `hoTenCha`, `hoTenMe`, `SDTPhuHuynh`, `diaChiLienHe`, `ghiChuHS`) VALUES
(1, 'Nguyễn Văn Anh', '04/11/2001', 'Nam', 'Bình Dương - Thăng Bình - Quảng Nam', '0355716962', 'A1', 'Nguyễn Văn Hùng', 'Phan Thị Hải', '0905641616', 'Bình Dương - Thăng Bình - Quảng Nam', 'chuyển lớp'),
(2, 'Nguyễn Thị Bé', '08/11/2000', 'Nữ', 'Bình Dương - Thăng Bình - Quảng Nam', '0616361494', 'A1', 'Nguyễn Văn Tài', 'Trần Thị Ánh Tuyến', '0368441675', 'Bình Dương - Thăng Bình - Quảng Nam', ''),
(3, 'Trần Văn Cương', '11/04/2000', 'Nam', 'Bình Dương - Thăng Bình - Quảng Nam', '0546474468', 'B1', 'Trần Văn Trung', 'Nguyễn Thị Kiều Anh', '0736296526', 'Bình Dương - Thăng Bình - Quảng Nam', ''),
(4, 'Trần Thị Mỹ Dung', '11/08/2000', 'Nữ', 'Bình Dương - Thăng Bình - Quảng Nam', '0548638786', 'C1', 'Trần Thanh Bình', 'Phan Thị Thu Nguyên', '0905595262', 'Bình Dương - Thăng Bình - Quảng Nam', ''),
(5, 'Phan Văn Hùng', '24/06/2000', 'Nam', 'Bình Dương - Thăng Bình - Quảng Nam', '0848653374', 'B1', 'Phan Văn Hổ', 'Nguyễn Thị Trân Châu', '0725625697', 'Bình Dương - Thăng Bình - Quảng Nam', 'Chuyển Trường'),
(6, 'Nguyễn Văn Anh', '04/11/2001', 'Nam', 'Bình Dương - Thăng Bình - Quảng Nam', '0701631625', 'A1', 'Nguyễn Văn Hùng', 'Phan Thị Hải', '0905641616', 'Bình Dương - Thăng Bình - Quảng Nam', 'chuyển lớp'),
(7, 'Trần Văn Hoàng Hải', '11/04/2000', 'Nam', 'Bình Dương - Thăng Bình - Quảng Nam', '0546474468', 'C1', 'Trần Văn Trung', 'Nguyễn Thị Kiều Anh', '0736296526', 'Bình Dương - Thăng Bình - Quảng Nam', 'lưu ban'),
(8, 'Trần Thị Hoàng Hải', '11/04/2000', 'Nữ', 'Bình Dương - Thăng Bình - Quảng Nam', '0546474468', 'B1', 'Trần Văn Trung', 'Nguyễn Thị Kiều Anh', '0736296526', 'Bình Dương - Thăng Bình - Quảng Nam', 'lưu ban');

-- --------------------------------------------------------

--
-- Table structure for table `lop`
--

CREATE TABLE `lop` (
  `maLop` char(5) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tenLop` char(5) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `maGiaoVien` int(5) NOT NULL,
  `ghiChuLop` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `lop`
--

INSERT INTO `lop` (`maLop`, `tenLop`, `maGiaoVien`, `ghiChuLop`) VALUES
('A1', '12A', 4, NULL),
('B1', '12B', 2, ''),
('C1', '12C', 3, ''),
('E1', '12E', 5, '');

-- --------------------------------------------------------

--
-- Table structure for table `monhoc`
--

CREATE TABLE `monhoc` (
  `maMonHoc` char(5) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tenMonHoc` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `maGiaoVien` int(5) NOT NULL,
  `ghiChuMon` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `monhoc`
--

INSERT INTO `monhoc` (`maMonHoc`, `tenMonHoc`, `maGiaoVien`, `ghiChuMon`) VALUES
('su', 'sử', 3, ''),
('toan', 'toán', 1, ''),
('van', 'Văn', 2, '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `idUser` int(5) NOT NULL,
  `userName` char(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `password` char(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `role` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`idUser`, `userName`, `password`, `role`) VALUES
(1, 'admin', '123456', 1),
(2, 'GV1', '123456', 2),
(3, 'HS1', '123456', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bangdiem`
--
ALTER TABLE `bangdiem`
  ADD KEY `maHocSinh` (`maHocSinh`),
  ADD KEY `maMonHoc` (`maMonHoc`);

--
-- Indexes for table `giaovien`
--
ALTER TABLE `giaovien`
  ADD PRIMARY KEY (`maGiaoVien`);

--
-- Indexes for table `hocsinh`
--
ALTER TABLE `hocsinh`
  ADD PRIMARY KEY (`maHocSinh`),
  ADD KEY `maLop` (`maLop`);

--
-- Indexes for table `lop`
--
ALTER TABLE `lop`
  ADD PRIMARY KEY (`maLop`),
  ADD KEY `maGiaoVien` (`maGiaoVien`);

--
-- Indexes for table `monhoc`
--
ALTER TABLE `monhoc`
  ADD PRIMARY KEY (`maMonHoc`),
  ADD KEY `maGiaoVien` (`maGiaoVien`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bangdiem`
--
ALTER TABLE `bangdiem`
  MODIFY `maHocSinh` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `giaovien`
--
ALTER TABLE `giaovien`
  MODIFY `maGiaoVien` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hocsinh`
--
ALTER TABLE `hocsinh`
  MODIFY `maHocSinh` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `lop`
--
ALTER TABLE `lop`
  MODIFY `maGiaoVien` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `monhoc`
--
ALTER TABLE `monhoc`
  MODIFY `maGiaoVien` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bangdiem`
--
ALTER TABLE `bangdiem`
  ADD CONSTRAINT `bangdiem_ibfk_2` FOREIGN KEY (`maHocSinh`) REFERENCES `hocsinh` (`maHocSinh`),
  ADD CONSTRAINT `bangdiem_ibfk_3` FOREIGN KEY (`maMonHoc`) REFERENCES `monhoc` (`maMonHoc`);

--
-- Constraints for table `hocsinh`
--
ALTER TABLE `hocsinh`
  ADD CONSTRAINT `hocsinh_ibfk_1` FOREIGN KEY (`maLop`) REFERENCES `lop` (`maLop`);

--
-- Constraints for table `lop`
--
ALTER TABLE `lop`
  ADD CONSTRAINT `lop_ibfk_1` FOREIGN KEY (`maGiaoVien`) REFERENCES `giaovien` (`maGiaoVien`);

--
-- Constraints for table `monhoc`
--
ALTER TABLE `monhoc`
  ADD CONSTRAINT `monhoc_ibfk_1` FOREIGN KEY (`maGiaoVien`) REFERENCES `giaovien` (`maGiaoVien`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
