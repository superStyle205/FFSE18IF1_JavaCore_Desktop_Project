-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 20, 2019 lúc 11:32 AM
-- Phiên bản máy phục vụ: 10.1.37-MariaDB
-- Phiên bản PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `quanlyhocsinh`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `diem`
--

CREATE TABLE `diem` (
  `MaSV` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MaMH` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `LanThi` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DiemThi` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `diem`
--

INSERT INTO `diem` (`MaSV`, `MaMH`, `LanThi`, `DiemThi`) VALUES
('111888', 'M32', '33334', '122'),
('123', 'M32', '2', '1'),
('12333', 'M32', '23', '9'),
('22', 'M32', '33211', '12122'),
('444', 'M32', '33', '12'),
('5323', 'M32', '332', '121'),
('7777', 'M32', '6', '-7');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `giaovien`
--

CREATE TABLE `giaovien` (
  `MaGV` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TenGV` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ChuyenNganh` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MaKhoa` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `giaovien`
--

INSERT INTO `giaovien` (`MaGV`, `TenGV`, `ChuyenNganh`, `MaKhoa`) VALUES
('122', 'adeas', 'ads2QƯE', 'M1'),
('12234', 'adeas', 'ads2QƯE', 'M1'),
('122344', 'adeas', 'ads2QƯE', 'M1'),
('1234', 'aaaa', '123321', 'M1'),
('55555', 'TRDFF', 'RÉDX', 'M1'),
('5555511', 'TRDFF', 'RÉDX', 'M1'),
('776', 'YHYHHY', 'YHYHY', 'M1'),
('999', 'trgg66666', 'ABCVVV', 'M1'),
('9998', 'HHII', 'JK', 'M1'),
('GV005', 'Ânh7777', 'CNTT777', 'M1'),
('GV06', 'HUYNH', 'ads2QƯE', 'M1'),
('gv555', 'adeas', 'ads2', 'M1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hocsinh`
--

CREATE TABLE `hocsinh` (
  `MaSV` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TenSV` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `MaLop` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `GioiTinh` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NgaySinh` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `hocsinh`
--

INSERT INTO `hocsinh` (`MaSV`, `TenSV`, `MaLop`, `GioiTinh`, `NgaySinh`) VALUES
('111888', 'QƯEê', 'B1', 'Nam', '123'),
('123', 'QƯE555', 'B1', 'Nam', '123'),
('12322111', 'QƯE555', 'B1', 'Nam', '123'),
('12322222', 'QƯE', 'B1', 'Nam', '123'),
('12333', 'QƯE', 'B1', 'Nam', '123'),
('12333123', 'QƯE', 'B1', 'Nam', '123555555'),
('151888', 'QƯEê666', 'B1', 'Nam', '123'),
('22', 'WWWLTTT', 'B1', 'Nam', '3333'),
('23213', 'nGUYỄN', 'B1', 'Nam', 'QƯE'),
('333', 'FCFC', 'B1', 'Nam', '323'),
('342', 'rrrr', 'B1', 'Nam', '3333'),
('444', 'scđ', 'B1', 'Nam', '2333'),
('5323', 'CDXSX', 'B1', 'Nữ', 'DÊ344'),
('55555', 'QƯE', 'B1', 'Nam', '123'),
('6555', '42332', 'B1', 'Nữ', '123094'),
('666', 'TDF', 'B1', 'Nam', '43443'),
('766', 'qưeqwe', 'B1', 'Nữ', '23445'),
('7777', 'TGFR', 'B1', 'Nữ', '44444'),
('777765', 'FFFF', 'B1', 'Nam', '66666'),
('8999', 'GH', 'B1', 'Nam', 'R4444');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `khoa`
--

CREATE TABLE `khoa` (
  `MaKhoa` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenkhoa` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `khoa`
--

INSERT INTO `khoa` (`MaKhoa`, `tenkhoa`) VALUES
('M1', 'T1'),
('M2', 'T5'),
('M3', 'T5'),
('M4', 'T5'),
('M5', 'T5'),
('M6', 'T2');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lop`
--

CREATE TABLE `lop` (
  `MaLop` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TenLop` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MaKhoa` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `lop`
--

INSERT INTO `lop` (`MaLop`, `TenLop`, `MaKhoa`) VALUES
('B1', 'HC', 'M1'),
('B2', 'ND2', 'M1'),
('B33', 'U7', 'M1'),
('BB2311', 'RR12', 'M1'),
('E3', 'S33', 'M1'),
('H5', 'AD', 'M1'),
('HO1', 'AD2', 'M1'),
('K22', 'AD2S', 'M1'),
('K231', 'BB2', 'M1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `monhoc`
--

CREATE TABLE `monhoc` (
  `MaMH` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TenMh` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SoGio` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `monhoc`
--

INSERT INTO `monhoc` (`MaMH`, `TenMh`, `SoGio`) VALUES
('B33', 'Hóa', '321'),
('H12', 'Hóa', '321'),
('M32', 'Toán', '123'),
('NƯ7', '222', '23'),
('S233', 'Lý', '321'),
('T123', 'Hóa', '321');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `taikhoan`
--

CREATE TABLE `taikhoan` (
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `taikhoan`
--

INSERT INTO `taikhoan` (`username`, `password`) VALUES
('ben123', 'truongdinhtai');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `diem`
--
ALTER TABLE `diem`
  ADD PRIMARY KEY (`MaSV`,`MaMH`),
  ADD KEY `MaSV` (`MaSV`,`MaMH`),
  ADD KEY `MaMH` (`MaMH`);

--
-- Chỉ mục cho bảng `giaovien`
--
ALTER TABLE `giaovien`
  ADD PRIMARY KEY (`MaGV`),
  ADD KEY `MaKhoa` (`MaKhoa`);

--
-- Chỉ mục cho bảng `hocsinh`
--
ALTER TABLE `hocsinh`
  ADD PRIMARY KEY (`MaSV`),
  ADD KEY `MaLop` (`MaLop`);

--
-- Chỉ mục cho bảng `khoa`
--
ALTER TABLE `khoa`
  ADD PRIMARY KEY (`MaKhoa`);

--
-- Chỉ mục cho bảng `lop`
--
ALTER TABLE `lop`
  ADD PRIMARY KEY (`MaLop`),
  ADD KEY `MaKhoa` (`MaKhoa`);

--
-- Chỉ mục cho bảng `monhoc`
--
ALTER TABLE `monhoc`
  ADD PRIMARY KEY (`MaMH`);

--
-- Chỉ mục cho bảng `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD PRIMARY KEY (`username`);

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `diem`
--
ALTER TABLE `diem`
  ADD CONSTRAINT `diem_ibfk_1` FOREIGN KEY (`MaSV`) REFERENCES `hocsinh` (`MaSV`),
  ADD CONSTRAINT `diem_ibfk_2` FOREIGN KEY (`MaMH`) REFERENCES `monhoc` (`MaMH`);

--
-- Các ràng buộc cho bảng `giaovien`
--
ALTER TABLE `giaovien`
  ADD CONSTRAINT `giaovien_ibfk_1` FOREIGN KEY (`MaKhoa`) REFERENCES `khoa` (`MaKhoa`);

--
-- Các ràng buộc cho bảng `hocsinh`
--
ALTER TABLE `hocsinh`
  ADD CONSTRAINT `hocsinh_ibfk_1` FOREIGN KEY (`MaLop`) REFERENCES `lop` (`MaLop`);

--
-- Các ràng buộc cho bảng `lop`
--
ALTER TABLE `lop`
  ADD CONSTRAINT `lop_ibfk_1` FOREIGN KEY (`MaKhoa`) REFERENCES `khoa` (`MaKhoa`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
