-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 20, 2019 lúc 11:14 AM
-- Phiên bản máy phục vụ: 10.1.37-MariaDB
-- Phiên bản PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `quan_li_truong_hoc`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bangdiem`
--

CREATE TABLE `bangdiem` (
  `sothutu` int(10) NOT NULL,
  `mahs` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenhs` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lop` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toan` double DEFAULT NULL,
  `vatli` double DEFAULT NULL,
  `hoahoc` double DEFAULT NULL,
  `sinhhoc` double DEFAULT NULL,
  `lichsu` double DEFAULT NULL,
  `diali` double DEFAULT NULL,
  `gdcd` double DEFAULT NULL,
  `congnghe` double DEFAULT NULL,
  `tinhoc` double DEFAULT NULL,
  `nguvan` double DEFAULT NULL,
  `tienganh` double DEFAULT NULL,
  `gdqp` double DEFAULT NULL,
  `theduc` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `bangdiem`
--

INSERT INTO `bangdiem` (`sothutu`, `mahs`, `tenhs`, `lop`, `toan`, `vatli`, `hoahoc`, `sinhhoc`, `lichsu`, `diali`, `gdcd`, `congnghe`, `tinhoc`, `nguvan`, `tienganh`, `gdqp`, `theduc`) VALUES
(1, '1800001', 'Nguyen Van A', '10A1', 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5),
(2, '1800002', 'Nguyen Van A', '10A1', 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5),
(3, '1800003', 'Nguyen Van A', '10A3', 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5),
(4, '1800004', 'Nguyen Van lí', '10A6', 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5),
(6, '1800005', 'Nguyen Van A', '10A6', 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5, 7.5),
(7, '1800007', 'Nguyễn Thị Loan', '10A6', 7, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5),
(8, '1800008', 'Nguyễn Văn Huy', '10A6', 8, 6, 7, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6),
(9, '1800009', 'Bùi Xuân Hạnh', '10A5', 7, 7, 7, 5, 8, 6, 9, 9, 7, 7, 5, 8, 7),
(10, '1800010', 'sdf', '10A1', 7, 7, 7, 5, 5, 5, 4, 5, 9, 7, 5, 8, 7),
(11, '1800011', 'Nguyễn Văn Tuấn', '10A3', 5, 6, 7, 7, 6, 5, 8, 8, 5, 7, 6, 8, 8);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hosohocsinh`
--

CREATE TABLE `hosohocsinh` (
  `sothutu` int(10) DEFAULT NULL,
  `mahs` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenhs` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gioitinh` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ngaysinh` date DEFAULT NULL,
  `lop` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diachi` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dantoc` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tongiao` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenbo` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenme` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nghenghiepbo` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nghenghiepme` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sodienthoaibo` int(12) DEFAULT NULL,
  `sodienthoaime` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `hosohocsinh`
--

INSERT INTO `hosohocsinh` (`sothutu`, `mahs`, `tenhs`, `gioitinh`, `ngaysinh`, `lop`, `diachi`, `dantoc`, `tongiao`, `tenbo`, `tenme`, `nghenghiepbo`, `nghenghiepme`, `sodienthoaibo`, `sodienthoaime`) VALUES
(1, '1800001', 'Nguyễn Văn Huy', 'Nam', '2000-10-10', '10A2', 'Đà Nẵng', 'Kinh', 'Không', 'Nguyễn Văn Tuấn', 'Nguyễn Thị Lan', 'Bác Sĩ', 'Giáo Viên', 372348350, 356541542),
(2, '1800002', 'Nguyễn Thị Thu', 'Nữ', '2000-11-20', '10A4', 'Đã Nẵng', 'Kinh', 'Có', 'Nguyễn Văn Huy', 'Nguyễn Thị Dung', 'Nông nghiệp', 'nông nghiệp', 231454, 320121);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ketquahoctap`
--

CREATE TABLE `ketquahoctap` (
  `sothutu` int(10) NOT NULL,
  `mahs` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenhs` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diemtrungbinhmon` double DEFAULT NULL,
  `xeploai` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hanhkiem` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ketqua` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `ketquahoctap`
--

INSERT INTO `ketquahoctap` (`sothutu`, `mahs`, `tenhs`, `diemtrungbinhmon`, `xeploai`, `hanhkiem`, `ketqua`) VALUES
(1, '1800001', 'nguyen van a', 5, 'Trung Bình', 'Tốt', 'Được lên lớp'),
(2, '1800002', 'nguyen văn C', 2, 'Yếu', 'Khá', 'Ở lại lớp'),
(3, '1800003', 'xdvc', 7, 'Giỏi', 'Tốt', 'Được lên lớp');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lop`
--

CREATE TABLE `lop` (
  `idlop` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lop` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `magv` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `monhoc`
--

CREATE TABLE `monhoc` (
  `idmon` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monhoc` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `magv` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `quanlidiem`
--

CREATE TABLE `quanlidiem` (
  `sothutu` int(10) DEFAULT NULL,
  `mahs` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenhs` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monhoc` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diemhocki1` double DEFAULT NULL,
  `diemhocki2` double DEFAULT NULL,
  `diemcuoinam` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `quanlidiem`
--

INSERT INTO `quanlidiem` (`sothutu`, `mahs`, `tenhs`, `monhoc`, `diemhocki1`, `diemhocki2`, `diemcuoinam`) VALUES
(1, '1800001', 'Nguyen Van A', 'Toan', 8.5, 7, 7.8),
(2, '1800002', 'Nguyen Van A', 'Toan', 8.5, 7, 7.8),
(3, '1800003', 'Nguyen Van b', 'Toan', 8.5, 7, 7.8),
(4, '1800004', 'Nguyen Van c', 'Ngu Van', 8.5, 7, 7.8),
(5, '1800005', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(6, '1800006', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(7, '1800007', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(8, '1800008', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(9, '1800009', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(10, '1800010', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(11, '1800011', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(12, '1800012', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(13, '1800013', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(14, '1800014', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(15, '1800015', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(16, '1800016', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(17, '1800017', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(18, '1800018', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(19, '1800019', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(20, '1800020', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(21, '1800021', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(22, '1800022', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(23, '1800023', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(24, '1800024', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(25, '1800025', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(26, '1800026', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(27, '1800027', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(28, '1800028', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(29, '1800029', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(30, '1800030', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(31, '1800031', 'Nguyen Van e', 'GDQP & AN', 8.5, 7, 7.8),
(32, '1800032', 'Nguyen Van e', 'Dia Li', 8.5, 7, 7.8),
(33, '1800033', 'Nguyen Van e', 'Dia Li', 8.5, 7, 7.8),
(34, '1800034', 'Nguyen Van e', 'Dia Li', 8.5, 7, 7.8),
(35, '1800035', 'Nguyen Van e', 'Dia Li', 8.5, 7, 7.8),
(36, '1800036', 'Nguyen Van e', 'Dia Li', 8.5, 7, 7.8),
(37, '1800037', 'Nguyen Van e', 'Dia Li', 8.5, 7, 7.8),
(38, '1800038', 'Nguyen Van e', 'Dia Li', 8.5, 7, 7.8),
(39, '1800039', 'Nguyen Van n', 'Dia Li', 8.5, 7, 7.8),
(40, '1800040', 'Nguyen Van h', 'Dia Li', 8.5, 7, 7.8),
(42, '1800041', 'Nguyen Van h', 'Sinh Học', 8.5, 8, 7.8),
(43, '1800043', 'Bùi Xuân Hạnh', 'Lịch Sử', 7, 8, 7),
(44, '1800044', 'Nguyễn Thị Loan', 'Sinh Học', 7, 7, 7),
(45, '1800045', 'dxcvx', 'Toán', 7, 8, 7),
(57, '1800057', 'Nguyễn Văn C', 'Vật Lí', 7, 8, 7);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `quanligiaovien`
--

CREATE TABLE `quanligiaovien` (
  `sothutu` int(10) DEFAULT NULL,
  `magv` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tengv` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gioitinh` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trinhdo` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diachi` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `choohiennay` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sotietdaytrongtuan` int(4) DEFAULT NULL,
  `songaynghi` int(4) DEFAULT NULL,
  `sodienthoai` int(12) DEFAULT NULL,
  `socmnd` int(20) DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `quanligiaovien`
--

INSERT INTO `quanligiaovien` (`sothutu`, `magv`, `tengv`, `gioitinh`, `trinhdo`, `diachi`, `choohiennay`, `sotietdaytrongtuan`, `songaynghi`, `sodienthoai`, `socmnd`, `email`) VALUES
(1, 'GV01', 'Nguyen Van A', 'Nam', 'Thac Si', 'Da Nang', 'Da Nang', 20, 1, 123456789, 13564235, 'hanhbui2705@gmail.com'),
(2, 'GV02', 'Nguyen Van A', 'Nam', 'Thac Si', 'Da Nang', 'Da Nang', 20, 1, 123456789, 13564235, 'hanhbui2705@gmail.com'),
(3, 'GV03', 'Nguyen Van A', 'Nam', 'Thac Si', 'Da Nang', 'Da Nang', 20, 1, 123456789, 13564235, 'hanhbui2705@gmail.com'),
(4, 'GV04', 'Nguyễn Văn B', 'Nam', 'giáo viên', 'Đà Nẵng', 'Đà Nẵng', 20, 1, 1562655, 214, 'hanhbui2705@gmail.com');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thongke`
--

CREATE TABLE `thongke` (
  `sothutu` int(10) NOT NULL,
  `lop` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tongso` int(5) DEFAULT NULL,
  `sohocsinhnam` int(5) DEFAULT NULL,
  `sohocsinhnu` int(5) DEFAULT NULL,
  `sohocsinhgioi` int(5) DEFAULT NULL,
  `sohocsinhkha` int(5) DEFAULT NULL,
  `sohocsinhtb` int(5) DEFAULT NULL,
  `sohocsinhyeu` int(5) DEFAULT NULL,
  `sohanhkiemtot` int(5) DEFAULT NULL,
  `sohanhkiemkha` int(5) DEFAULT NULL,
  `sohanhkiemtb` int(5) DEFAULT NULL,
  `sohanhkiemyeu` int(5) DEFAULT NULL,
  `sohocsinholailop` int(5) DEFAULT NULL,
  `sohocsinhthilai` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `thongke`
--

INSERT INTO `thongke` (`sothutu`, `lop`, `tongso`, `sohocsinhnam`, `sohocsinhnu`, `sohocsinhgioi`, `sohocsinhkha`, `sohocsinhtb`, `sohocsinhyeu`, `sohanhkiemtot`, `sohanhkiemkha`, `sohanhkiemtb`, `sohanhkiemyeu`, `sohocsinholailop`, `sohocsinhthilai`) VALUES
(4, '10A5', 40, 20, 20, 10, 20, 10, 0, 30, 8, 2, 0, 0, 0),
(5, '10A6', 40, 20, 20, 10, 20, 10, 0, 30, 8, 2, 0, 0, 0),
(6, '10A4', 40, 30, 20, 10, 20, 10, 0, 35, 5, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thongtingiaovien`
--

CREATE TABLE `thongtingiaovien` (
  `sothutu` int(10) NOT NULL,
  `magv` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tengv` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gioitinh` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ngaysinh` date DEFAULT NULL,
  `diachi` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lopchunhiem` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monday` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sodienthoai` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `thongtingiaovien`
--

INSERT INTO `thongtingiaovien` (`sothutu`, `magv`, `tengv`, `gioitinh`, `ngaysinh`, `diachi`, `lopchunhiem`, `monday`, `sodienthoai`) VALUES
(1, 'GV01', 'Nguyễn Văn A', 'Nam', '1975-10-15', 'Đà Nẵng', '10A4', 'Vật Lí', 6121355),
(2, 'GV02', 'Nguyễn Văn B', 'Nam', '1975-10-10', 'Đà Nẵng', '10A3', 'Hóa Học', 372348350);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thongtinsinhvien`
--

CREATE TABLE `thongtinsinhvien` (
  `sothutu` int(10) NOT NULL,
  `mahs` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenhs` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gioitinh` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ngaysinh` date DEFAULT NULL,
  `diachi` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenlop` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sodienthoai` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `thongtinsinhvien`
--

INSERT INTO `thongtinsinhvien` (`sothutu`, `mahs`, `tenhs`, `gioitinh`, `ngaysinh`, `diachi`, `tenlop`, `sodienthoai`) VALUES
(1, '1800001', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(2, '1800002', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(3, '1800003', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(4, '1800004', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(10, '1800010', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(13, '1800013', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(14, '1800014', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(15, '1800015', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(16, '1800016', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(17, '1800017', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(18, '1800018', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(19, '1800019', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(20, '1800020', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(21, '1800021', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(22, '1800022', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(23, '1800023', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(24, '1800024', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(26, '1800026', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(27, '1800027', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(28, '1800028', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(29, '1800029', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(30, '1800030', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(31, '1800031', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(32, '1800032', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(33, '1800033', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(34, '1800034', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(35, '1800035', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A1', 123456789),
(36, '1800036', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A3', 123456789),
(37, '1800037', 'Nguyen Van A', 'Nu', '2000-02-19', 'quang nam', '10A6', 123456789),
(38, '1800038', 'Nguyen Van A', 'Nu', '2000-02-19', 'quang nam', '10A6', 123456789),
(39, '1800039', 'Nguyen Van A', 'Nu', '2000-02-19', 'quang nam', '10A6', 123456789),
(40, '1800040', 'Nguyen Van A', 'Nu', '2000-02-19', 'quang nam', '10A6', 123456789),
(41, '1800041', 'Nguyen Van A', 'Nu', '2000-02-19', 'quang nam', '10A6', 123456789),
(42, '1800042', 'Nguyen Van A', 'Nu', '2000-02-19', 'quang nam', '10A6', 123456789),
(50, '1800050', 'Nguyen Van A', 'Nam', '2000-02-19', 'quang nam', '10A10', 123456789),
(52, '1800052', 'Nguyễn Tấn Huy', 'Nam', '2000-10-05', 'quang nam', '10A3', 3121),
(53, '1800053', 'Bùi Xuân Hạnh', 'Nam', '2000-05-27', 'Đà Nẵng', '10A5', 61321541),
(54, '1800054', 'Nguyễn Thị Loan', 'Nữ', '2000-09-12', 'Quảng Nam', '10A7', 613245),
(55, '1800055', 'Nguyễn Văn Huy', 'Nam', '2000-03-06', 'Quảng Nam', '10A4', 23454),
(56, '1800056', 'Nguyễn Thị B', 'Nữ', '2000-05-05', 'Đà Nẵng', '10A3', 652121545);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user_login`
--

CREATE TABLE `user_login` (
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user_login`
--

INSERT INTO `user_login` (`username`, `password`) VALUES
('admin', '27052000'),
('', ''),
('admin1', '55555');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `bangdiem`
--
ALTER TABLE `bangdiem`
  ADD PRIMARY KEY (`sothutu`),
  ADD KEY `mahs` (`mahs`);

--
-- Chỉ mục cho bảng `hosohocsinh`
--
ALTER TABLE `hosohocsinh`
  ADD PRIMARY KEY (`mahs`),
  ADD KEY `sothutu` (`sothutu`);

--
-- Chỉ mục cho bảng `ketquahoctap`
--
ALTER TABLE `ketquahoctap`
  ADD PRIMARY KEY (`sothutu`),
  ADD KEY `mahs` (`mahs`);

--
-- Chỉ mục cho bảng `lop`
--
ALTER TABLE `lop`
  ADD PRIMARY KEY (`lop`),
  ADD KEY `idlop` (`idlop`),
  ADD KEY `magv` (`magv`);

--
-- Chỉ mục cho bảng `monhoc`
--
ALTER TABLE `monhoc`
  ADD PRIMARY KEY (`idmon`),
  ADD KEY `monhoc` (`monhoc`),
  ADD KEY `magv` (`magv`);

--
-- Chỉ mục cho bảng `quanlidiem`
--
ALTER TABLE `quanlidiem`
  ADD PRIMARY KEY (`mahs`),
  ADD KEY `sothutu` (`sothutu`);

--
-- Chỉ mục cho bảng `quanligiaovien`
--
ALTER TABLE `quanligiaovien`
  ADD PRIMARY KEY (`magv`),
  ADD KEY `sothutu` (`sothutu`);

--
-- Chỉ mục cho bảng `thongke`
--
ALTER TABLE `thongke`
  ADD PRIMARY KEY (`sothutu`),
  ADD KEY `lop` (`lop`);

--
-- Chỉ mục cho bảng `thongtingiaovien`
--
ALTER TABLE `thongtingiaovien`
  ADD PRIMARY KEY (`sothutu`),
  ADD KEY `magv` (`magv`);

--
-- Chỉ mục cho bảng `thongtinsinhvien`
--
ALTER TABLE `thongtinsinhvien`
  ADD PRIMARY KEY (`sothutu`),
  ADD KEY `mahs` (`mahs`),
  ADD KEY `tenlop` (`tenlop`);

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `hosohocsinh`
--
ALTER TABLE `hosohocsinh`
  ADD CONSTRAINT `hosohocsinh_ibfk_1` FOREIGN KEY (`sothutu`) REFERENCES `thongtinsinhvien` (`sothutu`);

--
-- Các ràng buộc cho bảng `ketquahoctap`
--
ALTER TABLE `ketquahoctap`
  ADD CONSTRAINT `ketquahoctap_ibfk_1` FOREIGN KEY (`mahs`) REFERENCES `quanlidiem` (`mahs`),
  ADD CONSTRAINT `ketquahoctap_ibfk_2` FOREIGN KEY (`sothutu`) REFERENCES `bangdiem` (`sothutu`);

--
-- Các ràng buộc cho bảng `lop`
--
ALTER TABLE `lop`
  ADD CONSTRAINT `lop_ibfk_1` FOREIGN KEY (`magv`) REFERENCES `quanligiaovien` (`magv`);

--
-- Các ràng buộc cho bảng `monhoc`
--
ALTER TABLE `monhoc`
  ADD CONSTRAINT `monhoc_ibfk_1` FOREIGN KEY (`magv`) REFERENCES `quanligiaovien` (`magv`);

--
-- Các ràng buộc cho bảng `quanligiaovien`
--
ALTER TABLE `quanligiaovien`
  ADD CONSTRAINT `quanligiaovien_ibfk_1` FOREIGN KEY (`sothutu`) REFERENCES `thongtinsinhvien` (`sothutu`);

--
-- Các ràng buộc cho bảng `thongtingiaovien`
--
ALTER TABLE `thongtingiaovien`
  ADD CONSTRAINT `thongtingiaovien_ibfk_1` FOREIGN KEY (`magv`) REFERENCES `quanligiaovien` (`magv`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
