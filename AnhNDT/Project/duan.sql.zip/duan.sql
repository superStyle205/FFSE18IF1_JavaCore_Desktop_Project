-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 20, 2019 lúc 11:35 AM
-- Phiên bản máy phục vụ: 10.1.37-MariaDB
-- Phiên bản PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `duan`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `diem`
--

CREATE TABLE `diem` (
  `maMon` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tenMon` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `diemKtrHK1` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `diemKtrHK2` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `diemTB` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `giaovien`
--

CREATE TABLE `giaovien` (
  `maGiaoVien` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tenGiaoVien` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `emailGiaoVien` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sdtGiaoVien` varchar(12) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `maKhoi` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Đang đổ dữ liệu cho bảng `giaovien`
--

INSERT INTO `giaovien` (`maGiaoVien`, `tenGiaoVien`, `emailGiaoVien`, `sdtGiaoVien`, `maKhoi`) VALUES
('ád', 'ádas', '12', '23', '123'),
('n1', 'aaa', '12', '12', '122'),
('n2', 'aaa', '12', '12', '122'),
('wer', 'wer', '24', '234', '231');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hocsinh`
--

CREATE TABLE `hocsinh` (
  `maHocSinh` int(10) NOT NULL,
  `ten` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tuoi` int(4) NOT NULL,
  `sdt` int(12) NOT NULL,
  `diaChi` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `khoi`
--

CREATE TABLE `khoi` (
  `maKhoi` int(11) NOT NULL,
  `tenKhoi` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `login`
--

CREATE TABLE `login` (
  `username` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `password` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Đang đổ dữ liệu cho bảng `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lop`
--

CREATE TABLE `lop` (
  `malop` varchar(11) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tenlop` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tenGV` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `maKhoi` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Đang đổ dữ liệu cho bảng `lop`
--

INSERT INTO `lop` (`malop`, `tenlop`, `tenGV`, `maKhoi`) VALUES
('n1', 'abc', 'bac', '123'),
('n2', 'an', 'ad', '123'),
('n3', 'aaabbbb', 'ancc', '123'),
('n55555', 'avvvbbb', 'abnn', '321');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `mon`
--

CREATE TABLE `mon` (
  `maMon` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tenMon` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `maGV` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tenGV` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `soTiet` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ghiChu` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Đang đổ dữ liệu cho bảng `mon`
--

INSERT INTO `mon` (`maMon`, `tenMon`, `maGV`, `tenGV`, `soTiet`, `ghiChu`) VALUES
('n1', 'annan', 'a1', 'ananan', '12', 'nb'),
('n2', 'nn', 'a1', 'ncnc', '12', 'ncn'),
('n3', 'nn', 'a1', 'ncnc', '12', 'ncn'),
('n44', 'ewrewr', 'werewr', 'ewrewr', 'werewr', 'werewr'),
('n444875647464', 'ewrwer', 'sdfsdf', 'sdff', 'sdfdsf', 'sdsdf');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `diem`
--
ALTER TABLE `diem`
  ADD PRIMARY KEY (`maMon`);

--
-- Chỉ mục cho bảng `giaovien`
--
ALTER TABLE `giaovien`
  ADD PRIMARY KEY (`maGiaoVien`);

--
-- Chỉ mục cho bảng `hocsinh`
--
ALTER TABLE `hocsinh`
  ADD PRIMARY KEY (`maHocSinh`);

--
-- Chỉ mục cho bảng `khoi`
--
ALTER TABLE `khoi`
  ADD PRIMARY KEY (`maKhoi`);

--
-- Chỉ mục cho bảng `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Chỉ mục cho bảng `lop`
--
ALTER TABLE `lop`
  ADD PRIMARY KEY (`malop`);

--
-- Chỉ mục cho bảng `mon`
--
ALTER TABLE `mon`
  ADD PRIMARY KEY (`maMon`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
